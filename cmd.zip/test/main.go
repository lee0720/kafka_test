package main

import (
	"log"
	"main/kafka/product"
	"main/model"

	"github.com/Shopify/sarama"
)

/*
 "_source" : {
          "link" : "http://www.ebrun.com/20200918/402712.shtml",
          "id" : "2165203995",
          "title" : "生物制药研发商凯瑞康宁完成4000万美元C轮融资",
          "publish_date" : "2020-09-18 15:22:56"
        }
*/

func main() {

	producer, err := sarama.NewAsyncProducer([]string{"192.168.88.11:9082", "192.168.88.11:9083", "192.168.88.11:9084"}, nil)
	if err != nil {
		panic(err)
	}

	defer func() {
		if err := producer.Close(); err != nil {
			log.Fatalln(err)
		}
	}()

	entity_id := "1058552983"
	entity_type := model.EntityType_ORGANIZATION

	e := model.Entity{
		EntityID:   &entity_id,
		EntityType: &entity_type,
		EntityName: "潍坊市长松柴油机有限责任公司",
	}

	n := model.News{
		ID:              "2165203995",
		Title:           "生物制药研发商凯瑞康宁完成4000万美元C轮融资",
		Abstract:        "abstract",
		Content:         "content",
		PublishTime:     "2019-10-10 11:22:33",
		Link:            "http://www.ebrun.com/20200918/402712.shtml",
		PictureURL:      "PictureURL",
		RelatedEntities: []*model.Entity{&e},
	}

	product.Productor("message.News", n.ID, &n, producer)
}
